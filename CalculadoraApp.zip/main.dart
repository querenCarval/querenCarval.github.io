import 'package:flutter/material.dart';

void main() {
  runApp(const CalculadoraApp()); // Use const for MaterialApp
}

class CalculadoraApp extends StatelessWidget {
  const CalculadoraApp({Key? key}) : super(key: key); // Use const constructor

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculadora Web',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const Calculadora(), // Use const for stateless widgets
    );
  }
}

class Calculadora extends StatefulWidget {
  const Calculadora({Key? key}) : super(key: key);

  @override
  _CalculadoraState createState() => _CalculadoraState();
}

class _CalculadoraState extends State<Calculadora> {
  String _output = "0";
  double num1 = 0;
  double num2 = 0;
  String operand = "";

  void buttonPressed(String buttonText) {
    // Implement the logic to handle button presses and update the calculator state
    // ... (same logic as the previous calculator)
  }

  Widget buildButton(String buttonText) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(2.0),
        child: ElevatedButton(
          onPressed: () => buttonPressed(buttonText),
          child: Text(buttonText, style: const TextStyle(fontSize: 20)),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Calculadora Web'), // Use const for Text
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {
            return Column(
              children: <Widget>[
                Container(
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.symmetric(vertical: 24.0, horizontal: 12.0),
                  child: Text(
                    _output,
                    style: TextStyle(
                      fontSize: constraints.maxWidth / 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Expanded(child: Divider()),
                GridView.count(
                  crossAxisCount: constraints.maxWidth > 600 ? 4 : 3,
                  shrinkWrap: true,
                  children: [
                    "7",
                    "8",
                    "9",
                    "/",
                    "4",
                    "5",
                    "6",
                    "x",
                    "1",
                    "2",
                    "3",
                    "-",
                    ".",
                    "0",
                    "C",
                    "+",
                    "=",
                  ].map((buttonText) => buildButton(buttonText)).toList(),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}